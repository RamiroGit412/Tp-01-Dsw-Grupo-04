-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: ecommercerorders
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `orderitems`
--

DROP TABLE IF EXISTS `orderitems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orderitems` (
  `OrderItemId` char(36) NOT NULL,
  `OrderId` char(36) NOT NULL,
  `ProductId` char(36) NOT NULL,
  `Quantity` int NOT NULL,
  `UnitPrice` decimal(18,2) NOT NULL,
  `Subtotal` decimal(18,2) NOT NULL,
  PRIMARY KEY (`OrderItemId`),
  KEY `OrderId` (`OrderId`),
  KEY `ProductId` (`ProductId`),
  CONSTRAINT `orderitems_ibfk_1` FOREIGN KEY (`OrderId`) REFERENCES `orders` (`OrderId`),
  CONSTRAINT `orderitems_ibfk_2` FOREIGN KEY (`ProductId`) REFERENCES `products` (`ProductId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orderitems`
--

LOCK TABLES `orderitems` WRITE;
/*!40000 ALTER TABLE `orderitems` DISABLE KEYS */;
INSERT INTO `orderitems` VALUES ('090693de-0ab4-4f9f-8dca-f5d321a294d0','58139a8c-d25a-4252-9649-7c4a852efb8e','8bb3fe10-837c-403a-9543-57a24b2181f4',1,999.99,999.99),('3a71b1f4-225d-4c80-9f94-d71801d70816','bb90f5dd-b9a6-4902-830e-4de86bc87e55','8bb3fe10-837c-403a-9543-57a24b2181f4',1,999.99,999.99),('c346941d-e5cf-4c2e-803b-c80acd8487a4','f060ec77-c683-47a8-b906-70e613fc1653','8bb3fe10-837c-403a-9543-57a24b2181f4',1,999.99,999.99);
/*!40000 ALTER TABLE `orderitems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `OrderId` char(36) NOT NULL,
  `CustomerId` char(36) NOT NULL,
  `OrderDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `OrderStatus` varchar(50) NOT NULL,
  `TotalAmount` decimal(18,2) NOT NULL,
  `ShippingAddress` text NOT NULL,
  `BillingAddress` text NOT NULL,
  `Notes` text,
  PRIMARY KEY (`OrderId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES ('58139a8c-d25a-4252-9649-7c4a852efb8e','11111111-1111-1111-1111-111111111111','2025-06-20 17:41:45','Processing',999.99,'Av. Siempre Viva 742','Av. Siempre Viva 742',NULL),('bb90f5dd-b9a6-4902-830e-4de86bc87e55','11111111-1111-1111-1111-111111111111','2025-06-20 18:02:33','Pending',999.99,'Av. Siempre Viva 742','Av. Siempre Viva 742',NULL),('f060ec77-c683-47a8-b906-70e613fc1653','11111111-1111-1111-1111-111111111111','2025-06-20 18:08:35','Pending',999.99,'Av. Siempre Viva 742','Av. Siempre Viva 742',NULL);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `ProductId` char(36) NOT NULL,
  `SKU` varchar(50) NOT NULL,
  `InternalCode` varchar(50) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Description` text,
  `CurrentUnitPrice` decimal(18,2) NOT NULL,
  `StockQuantity` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`ProductId`),
  UNIQUE KEY `SKU` (`SKU`),
  UNIQUE KEY `InternalCode` (`InternalCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES ('11111111-1111-1111-1111-111111111111','ABC-123','PROD001','Auriculares Gamer','Auriculares con micrófono y luz LED',5999.99,10),('8bb3fe10-837c-403a-9543-57a24b2181f4','SKU-001','INT-001','Producto de prueba','Este es un producto de prueba para testing del TP',999.99,7);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-21 16:48:25
