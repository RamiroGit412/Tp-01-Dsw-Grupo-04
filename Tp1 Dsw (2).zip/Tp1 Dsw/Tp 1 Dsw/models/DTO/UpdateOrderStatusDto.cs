﻿namespace Tp_1_Dsw.models.DTO
{
    public class UpdateOrderStatusDto
    {
        public string NewStatus { get; set; } = null!;
    }
}
