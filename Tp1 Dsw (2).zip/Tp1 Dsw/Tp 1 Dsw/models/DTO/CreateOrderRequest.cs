﻿using System;
using System.Collections.Generic;

namespace Tp_1_Dsw.models.Dtos
{
    public class CreateOrderRequest
    {
        public Guid CustomerId { get; set; }
        public string ShippingAddress { get; set; } = null!;
        public string BillingAddress { get; set; } = null!;
        public List<CreateOrderItemDto> OrderItems { get; set; } = new();
    }

    public class CreateOrderItemDto
    {
        public Guid ProductId { get; set; }
        public int Quantity { get; set; }
    }
}
