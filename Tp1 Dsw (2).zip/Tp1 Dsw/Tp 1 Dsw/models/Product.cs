﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Tp_1_Dsw.models
{
    public class Product
    {
        // Constructor para inicializar valores requeridos
        public Product()
        {
            ProductId = Guid.NewGuid();
            SKU = string.Empty;
            InternalCode = string.Empty;
            Name = string.Empty;
            Description = string.Empty; // O puedes hacerla nullable con string?
        }

        [Key]
        public Guid ProductId { get; set; }

        [Required]
        [MaxLength(50)]
        public string SKU { get; set; }

        [Required]
        [MaxLength(50)]
        public string InternalCode { get; set; }

        [Required]
        [MaxLength(255)]
        public string Name { get; set; }

        public string Description { get; set; }

        [Required]
        [Range(0.01, double.MaxValue, ErrorMessage = "El precio debe ser mayor a 0")]
        public decimal CurrentUnitPrice { get; set; }

        [Required]
        [Range(0, int.MaxValue, ErrorMessage = "El stock no puede ser negativo")]
        public int StockQuantity { get; set; }
    }
}