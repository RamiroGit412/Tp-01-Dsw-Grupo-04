﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Tp_1_Dsw.models
{
    public class Order
    {
        [Key]
        public Guid OrderId { get; set; } = Guid.NewGuid();

        [Required]
        public Guid CustomerId { get; set; }

        public DateTime OrderDate { get; set; } = DateTime.Now;

        [Required]
        public string OrderStatus { get; set; } = "Pending";

        [Required]
        public decimal TotalAmount { get; set; } = 0m;

        [Required]
        public string ShippingAddress { get; set; } = null!; // Opción 2

        [Required]
        public required string BillingAddress { get; set; } // Opción 1 (C# 11+)

        public string? Notes { get; set; } // Opción 3 (nullable)

        public List<OrderItem> OrderItems { get; set; } = [];
    }
}