﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Tp_1_Dsw.Data;
using Tp_1_Dsw.models;
using Tp_1_Dsw.models.DTO;
using Tp_1_Dsw.models.Dtos;

namespace Tp_1_Dsw.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OrdersController(AppDbContext context) : ControllerBase
    {
        private readonly AppDbContext _context = context;

        // POST: /api/orders
        [HttpPost]
        public async Task<IActionResult> CreateOrder([FromBody] CreateOrderRequest request)
        {
            var orderItems = new List<OrderItem>();
            decimal total = 0;

            foreach (var item in request.OrderItems)
            {
                var product = await _context.Products.FindAsync(item.ProductId);
                if (product == null)
                    return BadRequest($"Producto con ID {item.ProductId} no encontrado.");

                if (product.StockQuantity < item.Quantity)
                    return BadRequest($"Stock insuficiente para el producto {product.Name}.");

                var subtotal = item.Quantity * product.CurrentUnitPrice;
                total += subtotal;

                product.StockQuantity -= item.Quantity;

                orderItems.Add(new OrderItem
                {
                    OrderItemId = Guid.NewGuid(),
                    ProductId = product.ProductId,
                    Quantity = item.Quantity,
                    UnitPrice = product.CurrentUnitPrice,
                    Subtotal = subtotal
                });
            }

            var order = new Order
            {
                OrderId = Guid.NewGuid(),
                CustomerId = request.CustomerId,
                ShippingAddress = request.ShippingAddress,
                BillingAddress = request.BillingAddress,
                OrderItems = orderItems,
                TotalAmount = total,
                OrderStatus = "Pending" // Estado inicial
            };

            _context.Orders.Add(order);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetOrderById), new { id = order.OrderId }, order);
        }

        // GET: /api/orders/{id}
        [HttpGet("{id}")]
        public async Task<IActionResult> GetOrderById(Guid id)
        {
            var order = await _context.Orders
                .Include(o => o.OrderItems)
                .ThenInclude(oi => oi.Product)
                .FirstOrDefaultAsync(o => o.OrderId == id);

            if (order == null)
                return NotFound();

            return Ok(order);
        }

        // GET: /api/orders
        [HttpGet]
        public async Task<IActionResult> GetOrders(
            [FromQuery] string? status,
            [FromQuery] Guid? customerId,
            [FromQuery] int pageNumber = 1,
            [FromQuery] int pageSize = 10)
        {
            var query = _context.Orders
                .Include(o => o.OrderItems)
                .ThenInclude(oi => oi.Product)
                .AsQueryable();

            if (!string.IsNullOrEmpty(status))
                query = query.Where(o => o.OrderStatus == status);

            if (customerId.HasValue)
                query = query.Where(o => o.CustomerId == customerId.Value);

            var totalOrders = await query.CountAsync();

            var orders = await query
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            return Ok(new
            {
                total = totalOrders,
                page = pageNumber,
                pageSize,
                data = orders
            });
        }

        // PUT: /api/orders/{id}/status
        [HttpPut("{id}/status")]
        public async Task<IActionResult> UpdateOrderStatus(Guid id, [FromBody] UpdateOrderStatusDto dto)
        {
            var order = await _context.Orders.FindAsync(id);
            if (order == null)
                return NotFound($"Orden con ID {id} no encontrada.");

            var validStatuses = new[] { "Pending", "Processing", "Shipped", "Delivered", "Cancelled" };
            if (!validStatuses.Contains(dto.NewStatus))
                return BadRequest($"Estado inválido. Estados permitidos: {string.Join(", ", validStatuses)}");

            order.OrderStatus = dto.NewStatus;
            await _context.SaveChangesAsync();

            return Ok(order);
        }
    }
}